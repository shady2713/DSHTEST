/**
 * The single writer over the plugin's business data.
 *
 * Exactly one Host service owns writes: the UI, tools, and tasks all call this
 * service rather than opening the unit themselves, so one place decides what a
 * lifecycle transition means for in-flight work. The backend unit does not
 * serialize concurrent writes, so this service also owns the write chain that
 * orders them.
 *
 * The lifecycle flag deliberately outlives fiber disposal. Disabling the plugin
 * disposes this fiber, but an Agent may still hold the service object through
 * a retired preset revision; that Agent must be able to read `draining` and
 * refuse to dispatch, so teardown marks the state first and only then closes the
 * unit.
 *
 * @module dsh-plugin-web-test/store-service
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import type { KvUnit, Storage } from '@deepseek-ai/dsh-storage';
import type { CaseResultRecord, EnvironmentRevisionRecord, CasePlanRecord, AuthorityToken, OperationRecord, PluginLifecycleState, RunHoldStatus, RunRecord, PluginStatus, PolicyRecord, ProjectRecord, RoleIdentityRecord, RunControlAction } from './types.ts';
/** Plugin version, matching this package's manifest. */
export declare const PLUGIN_VERSION = "0.7.6";
/**
 * Host release this plugin's peer declaration accepts.
 *
 * Reported so an operator reading the status can see which host compatibility
 * the loaded artifact was built against. The host itself enforces the actual
 * range before install, so this is a statement of intent, not a runtime probe.
 */
export declare const COMPATIBLE_DSH_VERSION = "0.2.0-rc.2";
/** Every table's records, keyed by table name. */
type Tables = Record<string, Record<string, unknown>>;
/** What one restart found that needs an operator's decision. */
/** What the site answered when a role's identity was checked. */
export interface VerifiedIdentity {
    /** The account the site reported, or an empty string when it reported none. */
    account: string;
    /** The site's own wording, kept so a failure can be reported as it stated it. */
    detail: string;
}
export interface ReconciliationReport {
    /** Runs a restart interrupted; each needs explicit continuation. */
    readonly blockedRuns: readonly string[];
    /** Operations whose dispatch state could not be observed before the restart. */
    readonly unknownOperations: readonly {
        runKey: string;
        operationKey: string;
        reason: string;
    }[];
}
/**
 * Single-writer service over the plugin's own storage unit.
 *
 * @typert service webTestStore
 */
export declare class WebTestStore extends Service {
    /** Unit opened over the plugin-owned SQLite backend; absent until opened. */
    unit: KvUnit | undefined;
    /** Current lifecycle state, readable even after this fiber is disposed. */
    state: PluginLifecycleState;
    /** Data root created at open time and reported in status. */
    dataRoot: string;
    /** Teardown in flight, joined by repeated drains. */
    draining: Promise<void> | undefined;
    /** Why the unit did not open, kept so status can report the cause. */
    openError: string | undefined;
    /** Readable records, held in memory so reads never re-parse the medium. */
    records: Tables;
    /** Tail of the write chain; every mutation appends to it. */
    writes: Promise<void>;
    /** What the last open found interrupted; empty on a clean first start. */
    reconciliation: ReconciliationReport;
    /**
     * @param ctx - Owning Context carrying the storage hub.
     */
    constructor(ctx: Context);
    /**
     * Whether new test actions may be dispatched right now.
     *
     * Tools and guards consult this rather than reading the fiber: an Agent that
     * retained a retired preset must still see the refusal.
     * @returns `true` only while the plugin is active and its unit is open.
     */
    get accepting(): boolean;
    /**
     * Return the store to active so a re-enabled plugin serves again.
     *
     * Disabling the bundle's root row drains this service, and the store row
     * itself is never disposed, so without re-arming here a re-enabled plugin
     * would stay `draining` until the host restarts. The next {@link open}
     * reopens the unit, because draining released it.
     */
    rearm(): void;
    /**
     * Open the plugin's own unit over its SQLite backend.
     *
     * The data root is created first so the backend's own directory handling never
     * widens permissions on a directory this plugin owns. A stored version the
     * schema does not accept rejects the open rather than producing empty-looking
     * tables, and a record that fails its table's schema rejects with the table
     * and key named instead of being dropped.
     * @param storage - The host's storage hub.
     * @returns the open unit.
     * @throws when the backend row is absent, the unit is already open, or the
     * medium carries a version or record shape this schema rejects.
     */
    open(storage: Storage): Promise<KvUnit>;
    /**
     * Load every table and validate each record against its declared schema.
     * @param unit - The open unit.
     * @returns the validated records keyed by table name.
     * @throws when a stored record does not match its table's schema.
     */
    private readRecords;
    /**
     * Persist one record and adopt the stored value in memory.
     *
     * Appended to this service's write chain because the unit does not serialize
     * concurrent writes; the in-memory table only advances after the medium
     * resolves, so a failed write leaves the readable state unchanged.
     * @param table - Declared table name.
     * @param key - Record key.
     * @param value - Record to store, already validated by the caller.
     * @returns resolution after durability.
     */
    private write;
    /**
     * Store one project, replacing any record with the same key.
     * @param project - Validated project record.
     * @returns the stored record.
     */
    putProject(project: ProjectRecord): Promise<ProjectRecord>;
    /**
     * Every readable project, ordered by key so callers see a stable list.
     * @returns the stored project records.
     */
    listProjects(): ProjectRecord[];
    /**
     * Store one environment declaration revision.
     * @param environment - Validated environment revision, keyed by its own `key`.
     * @returns the stored revision.
     */
    putEnvironment(environment: EnvironmentRevisionRecord): Promise<EnvironmentRevisionRecord>;
    /**
     * The root every run's evidence lives under.
     * @returns the absolute evidence root.
     */
    evidenceRoot(): string;
    /**
     * The directory this run's evidence belongs in, created on demand.
     *
     * The plugin owns evidence placement: a browser tool may write a file
     * anywhere, but only files the plugin can name and verify are recorded.
     * The directory is owner-only, so run evidence is not readable by other
     * local users.
     * @param runKey - Run whose evidence directory to prepare.
     * @returns the absolute directory path.
     */
    ensureEvidenceDir(runKey: string): string;
    /**
     * Apply an operator's control action to a running test.
     *
     * The held set is what the execution path reads, so a run the operator paused
     * or left waiting stops dispatching immediately rather than at the next model
     * turn, and only in the session that owns it.
     * @param runKey - Run to control.
     * @param action - What the operator asked for.
     * @returns the run record after the action.
     * @throws when no run carries that key, or the action contradicts its status.
     */
    controlRun(runKey: string, action: RunControlAction): Promise<RunRecord>;
    /**
     * Park a run until a business deadline, persisting the deadline itself.
     *
     * The deadline is durable rather than an in-memory timer, so a wait for a
     * business event survives the host closing and the run reports when it may
     * continue the next time the host runs.
     * @param runKey - Run to park.
     * @param untilMs - Earliest moment the run may act again.
     * @param reason - What the run is waiting for, for the report and operator.
     * @returns the run record after the wait was recorded.
     * @throws when the run is not running, or the deadline is not in the future.
     */
    waitUntil(runKey: string, untilMs: number, reason: string): Promise<RunRecord>;
    /**
     * Release a business-time wait once its deadline has passed.
     * @param runKey - Run to release.
     * @returns the run record after the wait ended.
     * @throws when the run is not waiting, or its deadline has not arrived.
     */
    resumeWait(runKey: string): Promise<RunRecord>;
    /**
     * The status an action produces, or undefined when the action is not allowed.
     *
     * A terminal status is terminal: a cancelled run stays cancelled because its
     * browser and evidence are gone, so re-enabling it would promise work that can
     * no longer be evidenced. Resuming returns a run straight to `running`, because
     * a pause leaves the session's browser alive and has nothing left to settle.
     * @param run - The run being controlled.
     * @param action - What the operator asked for.
     * @returns the resulting status, or undefined when the transition is invalid.
     */
    private static nextStatus;
    /**
     * Read one run or refuse by name, so every control path names the same cause.
     * @param runKey - Run to read.
     * @returns the stored run.
     * @throws when no run carries that key.
     */
    private requireRun;
    /**
     * Keep the held set in step with a run's status.
     *
     * Only a status that means "not executing right now" holds. A cancelled run is
     * finished and never holds, because holding it would stop every later run in
     * the host and nothing would ever clear that hold.
     * @param record - The run record about to be stored.
     */
    private applyHold;
    /**
     * The held run that stops one session, if any.
     *
     * A hold is scoped to the run's owning session so a paused run does not stop an
     * unrelated session's work. A held run with no recorded owner stops every
     * session, because the plugin cannot tell whose work interrupting it would end.
     * @param sessionId - Session asking, or empty when the caller has none.
     * @returns the held run and the reason it is held.
     */
    /**
     * The session's active run and the role it is verified to be acting as.
     *
     * This is the whole browser authorisation: a browser tool is dispatched only
     * when the run it belongs to is executing and that run's role was confirmed
     * against the site. Cancelling a run therefore revokes its browser without
     * touching another run or another session, because a later run is a
     * different run with its own authorisation.
     * @param sessionId - Session asking.
     * @returns the run key, its status, and the verified role, or nothing when
     * the session has no run that may drive a browser.
     */
    browserGrantForSession(sessionId: string): {
        runKey: string;
        status: RunRecord['status'];
        role: string;
    } | undefined;
    /**
     * The role the session's run is acting as right now.
     *
     * Read by the execution guard on every browser call, so browser reachability
     * follows the run's verified role rather than anything a model supplies.
     * @param sessionId - Session asking.
     * @returns the active role, or an empty string when none is set or verified.
     */
    activeRoleForSession(sessionId: string): string;
    holdForSession(sessionId: string): {
        runKey: string;
        status: RunHoldStatus;
    } | undefined;
    /**
     * Every run an operator currently holds, for the Client's run list.
     * @returns the held runs and their reasons.
     */
    heldRunList(): {
        runKey: string;
        status: RunHoldStatus;
    }[];
    /**
     * Store one run's record.
     * @param run - Validated run record, keyed by its run key.
     * @returns the stored run.
     */
    putRun(run: RunRecord): Promise<RunRecord>;
    /** Runs an operator held, so the execution path can refuse them by session. */
    private readonly authority;
    private readonly heldRuns;
    /** When each run's evidence directory was prepared, so stale files can be refused. */
    private readonly runStartedAt;
    /**
     * The moment this run's evidence directory was prepared.
     *
     * Evidence that predates the run cannot be this run's evidence, so a report
     * citing it is refused rather than recorded.
     * @param runKey - Run to read.
     * @returns the preparation time, or undefined when the run never prepared one.
     */
    runStartTime(runKey: string): number | undefined;
    /**
     * Read one run's current record.
     * @param runKey - Run to read.
     * @returns the stored run, or undefined when the key names no run.
     */
    getRun(runKey: string): RunRecord | undefined;
    /**
     * Every run, in key order.
     * @returns the stored run records.
     */
    listRuns(): RunRecord[];
    /**
     * Store one case's structured result.
     * @param result - Validated case result, keyed by its own `key`.
     * @returns the stored result.
     */
    /**
     * Store one proposed case, or the operator's ruling on it.
     * @param plan - Validated case plan, keyed by `<runKey>/<caseKey>`.
     * @returns the stored plan.
     */
    putCasePlan(plan: CasePlanRecord): Promise<CasePlanRecord>;
    /**
     * Read one case plan.
     * @param runKey - Run the case belongs to.
     * @param caseKey - Case to read.
     * @returns the stored plan, or undefined when the run proposed no such case.
     */
    getCasePlan(runKey: string, caseKey: string): CasePlanRecord | undefined;
    /**
     * Apply the operator's ruling on one proposed case.
     *
     * Ruling is an operator action rather than a model action, so it changes the
     * stored status and nothing else; a case the operator rejected can never be
     * executed, and a case left `proposed` is not executable either.
     * @param runKey - Run the case belongs to.
     * @param caseKey - Case to rule on.
     * @param decision - Whether the operator approved the case.
     * @param note - Why the operator decided this way.
     * @returns the plan after the ruling.
     * @throws when the run proposed no such case, or it was already ruled on.
     */
    ruleOnCase(runKey: string, caseKey: string, decision: 'confirm' | 'reject', note: string): Promise<CasePlanRecord>;
    putCaseResult(result: CaseResultRecord): Promise<CaseResultRecord>;
    /**
     * Record the intent to perform one business-changing operation, durably, before
     * the action that causes it.
     *
     * The record is written in `dispatching` on purpose: a transport loss or a
     * crash after this point may or may not have reached the business system, and
     * the honest state of that operation is `unknown`, not "not done". An operation
     * already in an unresolved state is refused, so replanning or renaming an
     * intent cannot become a second submission of the same change.
     * @param runKey - Run that will perform the operation.
     * @param operationKey - Short id the run names this operation by.
     * @param intent - The business change, for the report.
     * @param requestDigest - Digest of the request, so a repeat is recognisable.
     * @param role - Role performing it; must be declared by the run's environment.
     * @returns the stored operation record.
     * @throws when the run is not executing, the role is undeclared, or the
     * operation's outcome is already unresolved.
     */
    beginOperation(runKey: string, operationKey: string, intent: string, requestDigest: string, role: string): Promise<OperationRecord>;
    /**
     * Settle one operation from an observation independent of the dispatch.
     * @param runKey - Run that performed the operation.
     * @param operationKey - Operation to settle.
     * @param outcome - What the observation established.
     * @returns the stored operation record.
     * @throws when the operation does not exist or was never dispatched, because
     * an outcome for an undispatched operation would invent a business effect.
     */
    settleOperation(runKey: string, operationKey: string, outcome: 'observed-success' | 'observed-absent'): Promise<OperationRecord>;
    /**
     * Record that an operation's outcome could not be observed.
     *
     * This is the live equivalent of what a restart finds: the operation may or
     * may not have reached the business system, so it stays unresolved until an
     * operator settles it, and it is never dispatched again.
     * @param runKey - Run that attempted the operation.
     * @param operationKey - Operation whose outcome is unknown.
     * @param reason - What was observed to be lost.
     * @returns the stored operation record.
     * @throws when the operation does not exist or is already settled.
     */
    markOperationUnknown(runKey: string, operationKey: string, reason: string): Promise<OperationRecord>;
    /**
     * Store one operation's record, replacing any record with the same key.
     * @param operation - Validated operation record.
     * @returns the stored operation.
     */
    putOperation(operation: OperationRecord): Promise<OperationRecord>;
    /**
     * Read one operation of one run.
     * @param runKey - Run that owns the operation.
     * @param operationKey - Operation to read.
     * @returns the stored operation, or undefined when the run has no such operation.
     */
    getOperation(runKey: string, operationKey: string): OperationRecord | undefined;
    /**
     * Every operation of one run, in key order.
     * @param runKey - Run whose operations to read.
     * @returns the stored operation records.
     */
    listOperations(runKey?: string): OperationRecord[];
    /**
     * The operations of one run whose outcome is not yet established.
     * @param runKey - Run whose operations to read.
     * @returns the unresolved operation records.
     */
    unresolvedOperations(runKey: string): OperationRecord[];
    /**
     * Choose the role a run acts as, refusing a role the environment never declared.
     *
     * Role isolation starts from the declaration: a case may only act as a role the
     * operator listed, and a role may not change while a business-changing operation
     * is unresolved, because the run could not say which account produced that
     * effect.
     * @param runKey - Run changing role.
     * @param role - Role to act as; empty clears the current role.
     * @returns the run record after the change.
     * @throws when the run is not running, the role is undeclared, or an operation
     * is still unresolved.
     */
    assumeRole(runKey: string, role: string, verified: VerifiedIdentity): Promise<RunRecord>;
    /**
     * Mint the authority one verified role hands to the actions it may perform.
     *
     * The token names the run, the generation it was minted in, the agent that
     * holds it and the role it is for. It is random and unforgeable, so a caller
     * cannot assert its own authority the way it can assert a run key; every later
     * check re-reads the run rather than trusting the token's own claims.
     * @param runKey - Run whose verified role the authority belongs to.
     * @param agentId - Agent the authority is issued to.
     * @returns the token, or undefined when the run has no verified role.
     */
    mintAuthority(runKey: string, agentId: string): AuthorityToken | undefined;
    /**
     * The authority one run's current Agent already holds, without minting one.
     *
     * A later step in the same run has to act with the token `assume_role` issued,
     * and it should not have to be handed back and forth as an argument: echoing a
     * token through the model both widens what the model can assert and lets a
     * stale token be replayed. This reads the live token and re-checks it exactly
     * as `requireAuthority` would, so a run that restarted, lost its verified role or
     * changed generation yields nothing.
     * @param runKey - Run whose authority is wanted.
     * @param agentId - Agent asking, so another Agent's token is never returned.
     * @returns the live token, or undefined when the run has none.
     */
    currentAuthority(runKey: string, agentId: string): AuthorityToken | undefined;
    /**
     * Check a token against the run it names, right now.
     *
     * The run's own status and generation decide, so a token minted before a run
     * was cancelled, restarted or resumed stops working without anything having to
     * revoke it, and a token from one run can never act under another.
     * @param token - The token a call presented.
     * @param agentId - The agent making the call.
     * @returns the authority when it is still valid.
     * @throws when the token is unknown, belongs to another agent, or names a run
     * that is no longer running at the generation the token was minted in.
     */
    requireAuthority(token: string, agentId: string): AuthorityToken;
    /**
     * Read the recorded identity of one role.
     * @param runKey - Run to read.
     * @param role - Declared role name.
     * @returns the record, or undefined when the role was never verified.
     */
    getRoleIdentity(runKey: string, role: string): RoleIdentityRecord | undefined;
    /**
     * Store one role's verified identity.
     * @param record - The identity to store.
     * @returns the stored record.
     */
    putRoleIdentity(record: RoleIdentityRecord): Promise<RoleIdentityRecord>;
    /**
     * Record the account a role's browser actually presented.
     *
     * A separate record rather than a field on the run, so a report can say
     * which account produced which case and a later switch cannot overwrite the
     * evidence that the previous role really was signed in.
     * @param runKey - Run the identity belongs to.
     * @param role - Declared role name.
     * @param verified - What the site answered for that role's browser.
     */
    private putIdentity;
    /**
     * The account a role's browser presented when it was last switched to.
     * @param runKey - Run to read.
     * @param role - Declared role name.
     * @returns the verified account, or an empty string when never verified.
     */
    verifiedAccount(runKey: string, role: string): string;
    /**
     * Whether a run may prepare a role's identity in that role's browser.
     *
     * This is the preparation step, not access: it is what lets a person sign in
     * before the role is verified. It is scoped to a run that is executing and
     * owns the named role, so it cannot be used to reach another role's account,
     * another run, or another session.
     * @param sessionId - Session asking.
     * @param role - Role whose browser is being prepared.
     * @returns true when the session has a running run that declares the role.
     */
    /**
     * Every role any confirmed environment declares.
     *
     * A Web testing agent can drive exactly these roles. Environments confirmed
     * later are not covered, because the provider only defines a server's tools
     * on an agent as that agent is created.
     * @returns role names, without duplicates and in a stable order.
     */
    confirmedRoles(): string[];
    mayPrepareIdentity(sessionId: string, role: string, ownerRunKey?: string): boolean;
    /**
     * The account a declared role is bound to.
     *
     * A role whose `accountRef` names an account binds the role to it, so the
     * switch is checked against the environment the operator confirmed rather
     * than against a value the run produces. An `accountRef` that is not a
     * concrete account name (`ref:...`) binds nothing and returns an empty
     * string, which leaves the switch allowed but unverified against a name.
     * @param run - Run whose environment holds the binding.
     * @param role - Declared role name.
     * @returns the expected account, or an empty string when none is bound.
     */
    expectedAccount(run: RunRecord, role: string): string;
    /**
     * Every role the run's environment declares.
     *
     * Read at run start so a role's browser can be started before the model asks
     * to act as it: the browser provider hands an MCP server's tools to an Agent
     * when that Agent is created, so a browser started mid-turn is not callable
     * until the next one.
     * @param runKey - Run whose environment to read.
     * @returns the declared role names.
     * @throws when the run names an environment that is not stored.
     */
    declaredRoles(runKey: string): string[];
    /**
     * Resolve a role name against the run's environment declaration.
     * @param run - Run the role would act for.
     * @param role - Role name, empty to clear it.
     * @returns the role name, empty when the run acts without one.
     * @throws when the environment never declared that role.
     */
    private requireDeclaredRole;
    /**
     * Settle what a restart interrupted, instead of resuming it blindly.
     *
     * An operation that was in flight when the process stopped has an unobserved
     * outcome, so it becomes `unknown` and is never dispatched again. A run that
     * was still executing becomes `resuming`: it is neither executing nor a state
     * the operator chose, so it waits for an explicit continuation and refuses new
     * test actions meanwhile.
     *
     * A run that was already waiting keeps waiting. A wait for business time owns
     * a stored deadline that outlives the process, and a wait for an answer is
     * waiting on a person, so neither is something a restart decides. A
     * user-paused or cancelled run likewise keeps the state the operator chose.
     * @returns what the restart found that needs a decision.
     */
    private reconcileInterruptedWork;
    /**
     * Refuse recording into a run that is not executing.
     *
     * A result may only describe steps the run actually performed while it was
     * running, so a paused, waiting, cancelled or restart-interrupted run does not
     * accept new results; it must be continued first.
     * @param runKey - Run to check.
     * @returns the run, which is executing.
     * @throws when the run is missing or is not running.
     */
    requireExecutable(runKey: string): RunRecord;
    /**
     * Every recorded result of one run, in key order.
     * @param runKey - Run whose case results to read.
     * @returns the stored case results.
     */
    /**
     * Every proposed case of one run, in key order.
     * @param runKey - Run whose cases to read.
     * @returns the stored case plans.
     */
    listCasePlans(runKey: string): CasePlanRecord[];
    listCaseResults(runKey: string): CaseResultRecord[];
    /**
     * Every declared entry point of a project, newest revision first.
     * @param projectKey - Project whose entry points to read.
     * @returns the stored environment revisions.
     */
    listEnvironments(projectKey: string): EnvironmentRevisionRecord[];
    /**
     * Store one project's execution policy.
     * @param policy - Validated policy record, keyed by its own `key`.
     * @returns the stored policy.
     */
    putPolicy(policy: PolicyRecord): Promise<PolicyRecord>;
    /**
     * The records of one table in key order, so every list is stable.
     * @param table - Declared table name.
     * @returns the stored records sorted by key.
     */
    private sorted;
    /**
     * Count the records currently readable in each declared table.
     *
     * Reading this also proves the unit opened over its medium: an unreadable or
     * unknown-version store refuses to open rather than report zeros.
     * @returns record counts keyed by record kind.
     */
    recordCounts(): PluginStatus['recordCounts'];
    /**
     * Refuse new dispatches, then close the unit once queued writes settle.
     *
     * The state flips before the close is awaited so a concurrent dispatch is
     * refused for the whole teardown window, not only after the unit released its
     * backend. Idempotent: a second call joins the first teardown.
     * @returns resolution after the unit released its backend.
     */
    drain(): Promise<void>;
    /**
     * Snapshot for the Client: proves the Host half loaded and the plugin's own
     * storage answers.
     * @returns the plugin status, or `undefined` before the unit opened.
     */
    /**
     * What is waiting on the operator right now.
     *
     * A run a restart parked stays in that state until somebody continues it, so
     * the backlog outlives the startup report that first mentioned it. Operations
     * left `unknown` are listed with the reason, because those are the ones that
     * must not be repeated.
     * @returns the runs and operations awaiting a decision.
     */
    private needsDecision;
    status(): PluginStatus | undefined;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Single-writer service over the plugin's own business data. */
        webTestStore: WebTestStore;
    }
}
export default WebTestStore;
//# sourceMappingURL=store-service.d.ts.map