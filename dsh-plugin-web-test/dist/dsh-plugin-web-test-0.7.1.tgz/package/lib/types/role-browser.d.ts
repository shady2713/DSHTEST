/**
 * One isolated browser per role, with the model locked to the active role.
 *
 * The stock Playwright MCP provider mounts one browser per Session and offers
 * no tool that creates a second context, so two roles acting at once cannot
 * hold separate cookies through it. This module mounts one MCP server per role
 * instead: each runs the same pinned `@playwright/mcp` CLI with `--isolated`,
 * so every role gets its own Chromium process with its own cookie jar and
 * storage. It owns routing and release only — the browser, the agent loop, and
 * the host stay the ones the host already ships.
 *
 * Reachability is enforced with the host's own `tools.restrict`: every role's
 * tools are denied except the active role's, so the model has no path to
 * another role's browser while another role is active.
 *
 * @module dsh-plugin-web-test/src/role-browser
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import type ToolsService from '@deepseek-ai/dsh-tools';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import { z } from 'zod';
/** Loader identity of this service's row. */
export declare const name = "webTestRoleBrowsers";
/** Browser settings the operator configures for the test preset. */
export type RoleBrowserConfig = z.infer<typeof RoleBrowserPool.Config>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Per-role browser resources, owned by this plugin's own loader row. */
        webTestRoleBrowsers: RoleBrowserPool;
    }
}
/** How long a role's MCP server may take to come up before the switch fails. */
declare const ROLE_STARTUP_TIMEOUT_MS = 60000;
/** What one role's browser resource is and how to address it. */
export interface RoleBrowser {
    /** Role name the run declared for this browser. */
    readonly role: string;
    /** MCP server identity, which is also the tool namespace. */
    readonly serverName: string;
    /** Every tool this role's browser registers. */
    readonly toolNames: readonly string[];
}
/** A role's browser that came up, and the account the site reported for it. */
export interface VerifiedRole extends RoleBrowser {
    /** The account the site answered with, not the role name the run declared. */
    readonly account: string;
}
/** What a role's site answered when its identity was checked. */
export interface IdentityAnswer {
    /** Account the site reported, or an empty string when it reported none. */
    account: string;
    /** Raw response, kept so a failure can be reported as the site stated it. */
    detail: string;
}
/**
 * Per-role browser resources for one plugin instance.
 *
 * Browsers are started when a run switches to a role and released when the run
 * finishes, the plugin drains, or the process ends. Nothing here touches a
 * browser another session or an ordinary DSH conversation owns.
 */
export declare class RoleBrowserPool extends Service {
    /** Started role browsers, in the order they were created. */
    private readonly started;
    /** Roles whose mount is in flight, so a second caller waits on the same one. */
    private readonly pending;
    /** Disposers returned by `mountSessionMcp`, one per started role. */
    private readonly mounts;
    /** The role this pool currently drives; the host allows only one at a time. */
    private activeRole;
    /**
     * @param ctx - Owning context, which supplies the tools and browser services
     * the provider rows need.
     * @param executablePath - Chromium the role browsers launch; the host
     * installs no Playwright browser build, so this is a standalone Chrome.
     * @param headless - Whether role browsers run without a window.
     */
    static inject: string[];
    /** Browser settings the operator chooses on the loader row. */
    static Config: z.ZodObject<{
        executablePath: z.ZodOptional<z.ZodString>;
        headless: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strip>;
    /**
     * @param ctx - Owning context, which supplies the browser and tool services
     * each role's MCP server needs.
     * @param config - Chromium choice and window mode.
     */
    constructor(ctx: Context, config: RoleBrowserConfig);
    private readonly executablePath;
    private readonly headless;
    /**
     * Start a role's browser if it is not already up.
     *
     * Starting is idempotent because a run may switch back and forth between
     * roles, and a second browser for the same role would drop the login the
     * first one established.
     * @param role - Declared role name.
     * @returns the role's browser resource.
     */
    ensure(role: string): Promise<RoleBrowser>;
    /**
     * Make a role the one this pool drives, leaving any other mounted.
     *
     * A role's browser is kept once started. The provider gives every Agent its own
     * MCP client under its own scope, and each role registers a distinct
     * `browserUse` name, so two roles coexist rather than contending for one
     * browser. Releasing the previous role here was what made cross-role work
     * impossible: the first role's login and cookies were destroyed before the
     * second role existed.
     * @param role - The role to act as.
     * @returns the role's browser resource.
     */
    switchTo(role: string): Promise<RoleBrowser>;
    /**
     * The role this pool currently drives.
     * @returns the active role, or undefined when none is mounted.
     */
    active(): string | undefined;
    /**
     * Close one role's browser and wait for it.
     *
     * The effect that mounted the provider is disposed and awaited, so this
     * returns only after the provider has torn the browser down. A browser that
     * fails to close is reported rather than dropped.
     * @param role - The role to release.
     * @returns once the browser is closed.
     */
    releaseRole(role: string): Promise<void>;
    /**
     * Mount one role's MCP server and record it as started.
     * @param role - Declared role name.
     * @param browser - The resource to record once the server is mounted.
     * @returns once the server is mounted.
     */
    private mountBrowser;
    /**
     * Every role browser this pool has started.
     *
     *
     * Read at activation time: the provider registers an MCP server's tools when
     * a Session's agent activates, so a role started moments ago has none until
     * then, and the deny list is rebuilt each time the active role changes.
     * @returns the started role browsers.
     */
    list(): RoleBrowser[];
    /**
     * Tool names belonging to roles other than the active one.
     *
     * The model must not reach them: a second role's browser is a different
     * account, and using it would attribute one role's actions to another.
     * @param activeRole - Role the run is acting as, or an empty string.
     * @returns names to deny for the current activation.
     */
    forbiddenTools(activeRole: string): string[];
    /**
     * The tool namespace a role's browser actions live under.
     *
     * @param role - Declared role name.
     * @returns the prefix, for matching a tool back to its role.
     */
    static namespaceOf(role: string): string;
    /**
     * Which role a tool name belongs to, when it is one of ours.
     *
     * @param toolName - Global tool name as registered.
     * @returns the role name, or an empty string when the tool is not ours.
     */
    static roleOf(toolName: string): string;
    /**
     * Read the signed-in account back from the site, through this role's browser.
     *
     * Two nested tool calls: navigate to the identity endpoint, then read the
     * page text. Both are dispatched through the tools pipeline as nested calls
     * of the call that asked for the role, so the whole thing is logged as one
     * operation rather than as a browser action nobody declared.
     * @param tools - Tools service the role's browser tools are registered on.
     * @param exec - Execution identity of the call asking for verification.
     * @param role - Role whose browser to ask.
     * @param identityUrl - Site endpoint that reports the current account.
     * @returns the account the site reported and the text it reported it in.
     */
    readAccount(tools: ToolsService, exec: ToolRunContext, role: string, identityUrl: string): Promise<IdentityAnswer>;
    /**
     * Release every browser this pool started.
     *
     * Called when the plugin drains, which is also what a run's completion does,
     * so a run cannot leave a Chromium running after it stops.
     * @returns once every role's server is disposed.
     */
    releaseAll(): Promise<void>;
}
/**
 * How long a role browser may take to come up.
 *
 * Exposed so a caller can apply its own deadline instead of inventing one.
 */
export { ROLE_STARTUP_TIMEOUT_MS };
export default RoleBrowserPool;
//# sourceMappingURL=role-browser.d.ts.map