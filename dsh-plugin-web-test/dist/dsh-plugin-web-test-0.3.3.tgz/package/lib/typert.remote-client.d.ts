import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol'
import type { PluginStatus, ProjectRecord } from './types/index.js'

declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace77656254657374 {
    status: () => Promise<{ ok: true, value: RemotePluginStatus } | { ok: false, error: { code: string, message: string } }>
    putProject: (project: RemoteProject) => Promise<{ ok: true, value: RemoteProject } | { ok: false, error: { code: string, message: string } }>
    listProjects: () => Promise<{ ok: true, value: RemoteProject[] } | { ok: false, error: { code: string, message: string } }>
  }
  interface TypertRemoteNamespaceMap {
    "webTest": TypertRemoteNamespace77656254657374
  }
}

export declare const TYPERT_REMOTE: TypertRemoteContribution
export default TYPERT_REMOTE
