/**
 * Browser half of the `dsh-plugin-web-test` bundle.
 *
 * Registers the localized dictionaries and contributes one section to the host's
 * own Settings shell through the declared `settings.section` slot. Nothing here
 * is mounted unless the plugin is installed and enabled.
 *
 * @module dsh-plugin-web-test/client
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis service injection for the Client half. */
export declare const inject: string[];
/** Loader row id of the settings section. */
export declare const SECTION_ID = "web-test";
/** Position of the section among the host's settings sections. */
export declare const SECTION_ORDER = 90;
/**
 * Mount the Web testing Remote namespace and its settings section.
 *
 * The namespace exists only after the contribution is mounted, so the section
 * is registered from a scoped injection that declares it rather than from this
 * plugin's own `inject`, which the loader resolves before `apply` runs.
 * @param ctx - Plugin Context on the Client.
 * @returns a disposer withdrawing the section and the Remote namespace.
 */
export declare function apply(ctx: Context): Promise<() => void>;
//# sourceMappingURL=index.d.ts.map