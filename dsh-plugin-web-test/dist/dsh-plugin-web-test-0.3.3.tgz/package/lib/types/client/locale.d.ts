/**
 * Localized copy for the Web testing settings section.
 *
 * Every product-visible string the Client half shows lives here. `zh` and `en`
 * are both required: the locale runtime rejects a namespace that registers only
 * one of them.
 */
export declare const NS = "settings.webTest";
/** Simplified Chinese dictionary. */
export declare const zh: {
    title: string;
    heading: string;
    description: string;
    state: string;
    stateActive: string;
    stateDraining: string;
    version: string;
    dataRoot: string;
    schemaVersion: string;
    projects: string;
    runs: string;
    dshVersion: string;
    loading: string;
    projectsHeading: string;
    environmentsHeading: string;
    noProjects: string;
    noEnvironments: string;
    nature: string;
    natureTest: string;
    natureProduction: string;
    natureUnknown: string;
    dataOperations: string;
    dataReadOnly: string;
    dataBusinessWrites: string;
    viewport: string;
    roles: string;
    noRoles: string;
    readOnlyNotice: string;
    unavailable: string;
};
/** English dictionary. */
export declare const en: {
    title: string;
    heading: string;
    description: string;
    state: string;
    stateActive: string;
    stateDraining: string;
    version: string;
    dataRoot: string;
    schemaVersion: string;
    projects: string;
    runs: string;
    dshVersion: string;
    loading: string;
    projectsHeading: string;
    environmentsHeading: string;
    noProjects: string;
    noEnvironments: string;
    nature: string;
    natureTest: string;
    natureProduction: string;
    natureUnknown: string;
    dataOperations: string;
    dataReadOnly: string;
    dataBusinessWrites: string;
    viewport: string;
    roles: string;
    noRoles: string;
    readOnlyNotice: string;
    unavailable: string;
};
/** One environment declaration as the Client renders it. */
export interface WebTestEnvironmentSummary {
    readonly name: string;
    readonly url: string;
    readonly nature: 'test' | 'production' | 'unknown';
    readonly dataOperations: 'read-only' | 'business-entry-writes';
    readonly roles: readonly string[];
    readonly viewport: {
        readonly width: number;
        readonly height: number;
    };
}
/** One project with its declared entry points. */
export interface WebTestProjectSummary {
    readonly key: string;
    readonly label: string;
    readonly baseUrl: string;
    readonly environments: readonly WebTestEnvironmentSummary[];
}
/** Values injected into the settings section. */
export interface WebTestSettingsData {
    /** Status read from the Host when the section mounted. */
    readonly status: PluginStatus | undefined;
    /** Why the status could not be read, when the Remote call failed. */
    readonly failure: string | undefined;
    /** Recorded projects with their declared entry points. */
    readonly projects: readonly WebTestProjectSummary[];
}
/** Status the section renders, mirroring the Host service's own projection. */
export interface PluginStatus {
    readonly version: string;
    readonly state: 'active' | 'draining';
    readonly dataRoot: string;
    readonly schemaVersion: number;
    readonly recordCounts: {
        readonly project: number;
        readonly 'environment-revision': number;
        readonly run: number;
    };
    readonly dshVersion: string;
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.webTest': keyof typeof zh;
    }
}
//# sourceMappingURL=locale.d.ts.map