/**
 * Web testing settings section.
 *
 * Rendered inside the host's own Settings shell through the declared
 * `settings.section` slot, so the plugin adds a section without editing the
 * host's settings UI. All data arrives through the injected face; the component
 * never reaches for a Context or a service.
 */
import type { WebTestSettingsData } from './locale.ts';
/**
 * Props the slot renderer supplies to this component.
 *
 * The renderer flattens the registration's `inject` face into the component's
 * props, so the status arrives as sibling props rather than as one object.
 */
export interface WebTestSettingsSectionProps extends WebTestSettingsData {
    /** Localized `t` function supplied by the registering entry's inject face. */
    readonly t: (key: string, params?: Record<string, string | number>) => string;
}
/**
 * The Web testing settings section.
 * @param props - Slot props: the localized `t` function and the injected data.
 * @returns the section body.
 */
export declare function WebTestSettingsSection(props: WebTestSettingsSectionProps): JSX.Element;
//# sourceMappingURL=settings-section.d.ts.map