/**
 * The Web testing Host service and the plugin's typed Remote surface.
 *
 * The service owns three contributions and nothing else: it opens the plugin's
 * own storage unit over the plugin-owned SQLite backend, contributes the opt-in
 * `web-test` agent preset, and drains on unload. Business rules live in
 * `store-service.ts` and `agent.ts`; this module is the composition root the
 * host's loader rows and the Client's Remote calls address.
 *
 * The Client reaches it as `ctx.remote.webTest.*`, a typed namespace rather
 * than an ad-hoc HTTP surface, so its requests and results are validated by the
 * descriptors in `lib/typert.host.js`.
 *
 * @module dsh-plugin-web-test
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { PRESET_ID, name as AGENT_ROW } from './agent.ts';
import type { ReportBundle } from './report.ts';
import type { CasePlanRecord, CaseResultRecord, EnvironmentRevisionRecord, OperationRecord, PolicyRecord, ProjectRecord, RunControlAction, RunRecord } from './types.ts';
/** Loader row of the plugin's agent half, mounted inside the test preset. */
export { AGENT_ROW };
/** Id of the opt-in preset this plugin contributes. */
export { PRESET_ID };
/**
 * Web testing service, its storage owner, and its typed Remote namespace.
 * @typert service webTest
 */
export declare class WebTestService extends TypertRemoteService {
    /** Waits for the single writer so every business method goes through it. */
    static inject: string[];
    /**
     * @param ctx - Owning Context.
     */
    constructor(ctx: Context);
    /**
     * Opens storage and arranges teardown.
     *
     * The `web-test` preset is declared as a loader row in this bundle's
     * `cordis.patch.yml`, not registered here: a preset registered from code
     * carries entries that no loader ever starts.
     * @param ctx - Owning Context.
     */
    protected wire(ctx: Context): void;
    /**
     * Refuse business work once the plugin stopped accepting actions.
     * @throws when the plugin is draining or its storage is not open.
     */
    protected acceptingGuard(): void;
    /**
     * Report that the plugin loaded and its own storage answers.
     * @returns the plugin status.
     * @throws when the plugin is draining or its storage is not open.
     */
    status(): import("./types.ts").PluginStatus;
    /**
     * Store one project, replacing any record with the same key.
     * @param project - The project record to store, keyed by its own `key`.
     * @returns the stored record.
     * @throws when the plugin is draining or the record fails validation.
     */
    putProject(project: ProjectRecord): Promise<ProjectRecord>;
    /**
     * Store one environment declaration revision.
     * @param environment - The revision to store, keyed by its own `key`.
     * @returns the stored revision.
     * @throws when the plugin is draining or the record fails validation.
     */
    putEnvironment(environment: EnvironmentRevisionRecord): Promise<EnvironmentRevisionRecord>;
    /**
     * Read every declared entry point of one project.
     * @param projectKey - Project whose entry points to read.
     * @returns the stored environment revisions in key order.
     * @throws when the plugin is draining.
     */
    listEnvironments(projectKey: string): EnvironmentRevisionRecord[];
    /**
     * Store one project's execution policy.
     * @param policy - The policy to store, keyed by its own `key`.
     * @returns the stored policy.
     * @throws when the plugin is draining or the record fails validation.
     */
    putPolicy(policy: PolicyRecord): Promise<PolicyRecord>;
    /**
     * Pause, resume, cancel, or park one run, or answer the question it raised.
     *
     * This is the operator's side of the control surface: it changes the run's
     * status and the execution path's held set, so a run the operator stopped
     * refuses dispatching without waiting for the model's next turn, and only in
     * the session that owns it.
     * @param runKey - Run to control.
     * @param action - What the operator asked for.
     * @returns the run record after the action.
     * @throws when the plugin is draining, no run carries that key, or the action
     * contradicts the run's current status.
     */
    /**
     * Read every proposed case of one run, with the operator's ruling.
     *
     * This is the operator's view of what analysis proposed and what is therefore
     * executable, which is the pair the report needs in order to state coverage.
     * @param runKey - Run whose cases to read.
     * @returns the case plans in key order.
     * @throws when the plugin is draining.
     */
    listCases(runKey: string): CasePlanRecord[];
    /**
     * Approve or reject one proposed case.
     *
     * Approving is what makes a case executable: the tool that reports a result
     * refuses anything the operator has not approved, and refuses a result that
     * does not cover every approved step.
     * @param runKey - Run the case belongs to.
     * @param caseKey - Case to rule on.
     * @param decision - Whether the operator approved the case.
     * @param note - Why the operator decided this way.
     * @returns the plan after the ruling.
     * @throws when the plugin is draining, the run proposed no such case, or the
     * case was already ruled on.
     */
    ruleOnCase(runKey: string, caseKey: string, decision: 'confirm' | 'reject', note: string): Promise<CasePlanRecord>;
    controlRun(runKey: string, action: RunControlAction): Promise<RunRecord>;
    /**
     * Park a run until a business deadline, persisting the deadline itself.
     *
     * The deadline is durable, so a wait for a business event outlives the host
     * closing and the run reports when it may continue the next time it starts.
     * @param runKey - Run to park.
     * @param untilIso - ISO 8601 moment the run may act again at.
     * @param reason - What the run is waiting for.
     * @returns the run record after the wait was recorded.
     * @throws when the plugin is draining, the run is not running, or the deadline
     * is not in the future.
     */
    waitRun(runKey: string, untilIso: string, reason: string): Promise<RunRecord>;
    /**
     * Release a business-time wait once its stored deadline has passed.
     * @param runKey - Run to release.
     * @returns the run record after the wait ended.
     * @throws when the plugin is draining, the run is not waiting, or its deadline
     * has not arrived.
     */
    resumeWait(runKey: string): Promise<RunRecord>;
    /**
     * Choose the role a run acts as, refusing a role the environment never declared.
     * @param runKey - Run changing role.
     * @param role - Declared role name, empty to act without one.
     * @returns the run record after the change.
     * @throws when the plugin is draining, the run is not running, the role is
     * undeclared, or an operation is still unresolved.
     */
    assumeRole(runKey: string, role: string): Promise<RunRecord>;
    /**
     * Settle a business-changing operation whose outcome is now established, or
     * record that it could not be observed.
     *
     * An operation that was in flight when the host stopped is already `unknown`
     * when this opens, so the operator resolves it here instead of the run
     * repeating it.
     * @param runKey - Run that attempted the operation.
     * @param operationKey - Operation to resolve.
     * @param resolution - Either the observed outcome, or the reason it is unknown.
     * @returns the operation record after the resolution.
     * @throws when the plugin is draining, the operation does not exist, or the
     * transition is not allowed.
     */
    resolveOperation(runKey: string, operationKey: string, resolution: {
        outcome: 'observed-success' | 'observed-absent';
    } | {
        unknownReason: string;
    }): Promise<OperationRecord>;
    /**
     * Read one run's business-changing operations.
     * @param runKey - Run whose operations to read; omit for every run.
     * @returns the stored operation records in key order.
     * @throws when the plugin is draining.
     */
    listOperations(runKey?: string): OperationRecord[];
    /**
     * Read every recorded run, in key order.
     * @returns the stored run records.
     * @throws when the plugin is draining.
     */
    listRuns(): RunRecord[];
    /**
     * Read one run's current record.
     * @param runKey - Run to read.
     * @returns the run record.
     * @throws when the plugin is draining or no run carries that key.
     */
    getRun(runKey: string): RunRecord;
    /**
     * Build one run's report from its recorded case results and operations.
     *
     * All three forms come from one derivation, so the HTML a browser opens, the
     * Markdown a person reviews and the JSON a tool reads cannot disagree about
     * what the run did.
     * @param runKey - Run to report on.
     * @returns the report in Markdown, HTML and JSON, plus the verdict.
     * @throws when the plugin is draining.
     */
    buildReport(runKey: string): ReportBundle;
    /**
     * Read every recorded result of one run.
     * @param runKey - Run whose case results to read.
     * @returns the stored case results in key order.
     * @throws when the plugin is draining.
     */
    listCaseResults(runKey: string): CaseResultRecord[];
    /**
     * Read every stored project.
     * @returns the stored project records in key order.
     * @throws when the plugin is draining.
     */
    listProjects(): ProjectRecord[];
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Web testing service; also the plugin's typed Remote namespace. */
        webTest: WebTestService;
    }
}
export default WebTestService;
//# sourceMappingURL=index.d.ts.map