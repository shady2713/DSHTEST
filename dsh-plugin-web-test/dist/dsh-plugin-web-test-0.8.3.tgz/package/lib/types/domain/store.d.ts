/**
 * The plugin's own durable storage.
 *
 * Business records live in one KV unit owned by this plugin, never in DSH
 * shared attachments and never in session state. The unit is declared with the
 * `single` layout on purpose: that layout stores the whole unit as one
 * version-stamped document and the backend *rejects* an open whose stamped
 * version is unknown, which is what authoritative business data needs. The
 * `per-record` layout would instead discard a record it cannot read and let the
 * open succeed, turning a schema mismatch into apparent data loss.
 *
 * The unit is opened straight on this plugin's SQLite backend rather than
 * through the host's Storage Domain. Domain routing is a host `Config`
 * decision (`backend` plus per-domain `routes`), so a domain opened that way
 * lands on whatever backend the host routes `web_test` to — in a stock profile
 * that is the JSON backend, and this plugin's own database would stay empty.
 * Reaching for the backend by name keeps the data in the plugin's own file
 * without the plugin having to rewrite a host-owned row.
 *
 * @module dsh-plugin-web-test/domain/store
 */
import type { KvUnitDescriptor } from '@deepseek-ai/dsh-storage';
/** Plugin-owned data root name under `$DSH_HOME/plugins`. */
export declare const DATA_ROOT_NAME = "dsh-plugin-web-test";
/** Unit name; also the file-name and SQL-identifier segment, so it stays unique. */
export declare const DOMAIN_NAME = "web_test";
/**
 * Storage backend name registered by this plugin's own bundle row.
 *
 * Named here rather than read from configuration because the plugin owns the
 * row that registers it; a host that never mounted it fails loud at open.
 */
export declare const BACKEND_NAME = "sqlite";
/** Record kind keys; each is also a declared table name in the unit. */
export declare const TABLE_PROJECTS = "projects";
/** Environment revisions the operator confirmed for a project. */
export declare const TABLE_ENVIRONMENT_REVISIONS = "environment_revisions";
/** Test runs, their phases, and their evidence index. */
export declare const TABLE_RUNS = "runs";
/** Project-level execution policy. */
export declare const TABLE_POLICIES = "policies";
/** Structured per-case results produced by a test run. */
export declare const TABLE_CASE_RESULTS = "case_results";
/** Business-changing operations, durable before the action that causes them. */
export declare const TABLE_OPERATIONS = "operations";
/** Cases as analysis proposed them and the operator ruled on them. */
export declare const TABLE_CASE_PLANS = "case_plans";
/** Account each role's browser presented, written when a run switches role. */
export declare const TABLE_ROLE_IDENTITIES = "role_identities";
/**
 * Absolute path of the plugin-owned data root.
 *
 * `dshHomePath` only joins path segments; it never creates them and never
 * registers the path with the host, so the plugin owns this directory outright.
 * @returns the absolute plugin data root.
 */
export declare function dataRoot(): string;
/**
 * Create the plugin data root if absent, owner-only.
 *
 * Evidence and business data stay out of reach of other accounts on the
 * machine, which is also what the SQLite backend documents for its own files.
 * @returns the absolute plugin data root.
 * @throws when the directory cannot be created with owner-only permissions.
 */
export declare function ensureDataRoot(): Promise<string>;
/**
 * Program name of the platform's own access control tool.
 *
 * The name has to resolve on its own: passing a shell's `/c` as the program name
 * makes `execFile` look for a program literally called `/c` and fail with ENOENT.
 * @returns the executable to spawn directly, without a shell.
 */
export declare const ICACLS = "icacls.exe";
/** Local system, which always keeps access. */
export declare const SID_SYSTEM = "S-1-5-18";
/** The machine's built-in administrators group. */
export declare const SID_ADMINISTRATORS = "S-1-5-32-544";
/** Well-known principal that must never keep access to the data root. */
export declare const SID_EVERYONE = "S-1-1-0";
/**
 * Security identifiers the data root keeps access for.
 *
 * SYSTEM and the machine administrators keep it so there is still a recovery path
 * if the owning account's own entry is damaged. Both are identified by their
 * well-known SID rather than by their display name, because a display name is
 * localized: the same account reads `NT AUTHORITY\SYSTEM` on an English machine
 * and something else elsewhere, and comparing names is what let an explicit
 * `Everyone` entry survive a directory that was reported as restricted.
 * @param owner - Security identifier of the account the plugin runs as.
 * @returns the identifiers allowed to remain.
 */
export declare function sidsToKeep(owner: string): string[];
/**
 * The security identifier an account has, read from the output of `whoami /user`.
 *
 * Only the identifier itself is used. The surrounding words are localized, so
 * finding the SID by its own syntax keeps this working on a machine whose
 * `whoami` output this code has never seen.
 * @param output - Standard output of `whoami /user`.
 * @returns the identifier named by the output.
 * @throws when the output names no identifier.
 */
export declare function sidOfAccount(output: string): string;
/**
 * Security identifiers an ACL dump grants access to.
 *
 * `icacls /save` writes one line per path, each holding a descriptor in the form
 * `D:(A;;FA;;;S-1-5-18)`. That form is fixed by the platform rather than by the
 * machine's display settings, and it names every entry by identifier, so this
 * reads the whole tree the dump covered, not only the first path's line.
 * @param dump - Contents of an `icacls /save` file.
 * @returns every distinct identifier the dump grants access to.
 */
export declare function sidsOfAclDump(dump: string): string[];
/**
 * Every security identifier a tree grants access to, including paths other than
 * its root.
 *
 * Reading only the root is not enough. An entry written on a file before its
 * parent was restricted keeps that file readable afterwards, which is exactly how
 * an explicit `Everyone` grant survives on a child while the root looks clean.
 * @param dump - Contents of an `icacls /save` file covering the whole tree.
 * @returns the identifiers the dump names.
 */
export declare function sidsInTree(dump: string): string[];
/**
 * A deliberately lenient scan used only to check a result.
 *
 * This collects identities rather than enumerating them: any identifier at all
 * in the tree has to be one of the ones allowed to remain. The restriction itself
 * decides what to remove from {@link sidsToKeep}, so a defect in that enumeration
 * cannot also decide that the check passed.
 * @param dump - Contents of an `icacls /save` file.
 * @returns identifiers present in the dump.
 */
export declare function anySidsPresent(dump: string): string[];
/**
 * The call that drops every entry a directory inherits from its parent.
 * @param root - Absolute plugin data root to restrict.
 * @returns the argument vector to execute.
 */
export declare function inheritanceRemovalFor(root: string): string[];
/**
 * The call that takes access away from one identity.
 *
 * `/inheritance:r` drops inherited entries only. An explicit grant written by an
 * earlier run, or inherited into a file before its parent was changed, stays in
 * place: that is how an explicit `Everyone` read survives a "restricted"
 * directory. Each unwanted identity therefore has to be removed by name.
 *
 * The name is a SID with the leading `*` that tells `icacls` to read it as an
 * identifier rather than look it up as an account name. That avoids depending on
 * a localized display name; the `*` form has not been exercised on Windows.
 * @param root - Absolute plugin data root to restrict.
 * @param sid - Security identifier to take access from.
 * @returns the argument vector to execute.
 */
export declare function removalFor(root: string, sid: string): string[];
/**
 * The call that gives the owning account full control, replacing its own entry.
 * @param root - Absolute plugin data root to restrict.
 * @param owner - Account name or security identifier the plugin runs as.
 * @returns the argument vector to execute.
 */
export declare function grantFor(root: string, owner: string): string[];
/**
 * The calls that restrict one directory, in the order they have to run.
 *
 * The owner is granted first, on purpose. A removal that fails partway through
 * used to leave the directory with no entry for the account running the plugin:
 * `/inheritance:r` had already run and the grant that came after the removals
 * never did, so the plugin could not write to its own data root and the caller's
 * account was worse off than before the call. Granting first means the owning
 * account's access is established before anything is taken away, and stays
 * established if a later step throws.
 * @param root - Absolute plugin data root to restrict.
 * @param sids - Identifiers the tree currently grants access to.
 * @param owner - Account the plugin runs as.
 * @returns the argument vectors to execute in order.
 */
export declare function restrictCommandsForWindows(root: string, sids: string[], owner: string): string[][];
/**
 * Append the recursive form of each call.
 *
 * Restricting a directory only governs what is created afterwards: an existing
 * SQLite database, its write-ahead log and shared-memory file, and the evidence
 * directories from earlier runs keep the entries they were created with.
 * @param commands - Calls produced for one directory.
 * @returns the same calls with `/T` appended, to run against everything under it.
 */
export declare function restrictTreeCommandsForWindows(commands: string[][]): string[][];
/**
 * Reparse points at or under the data root, each as an absolute path.
 *
 * `/T` walks into whatever it finds, so a junction planted inside the data root
 * would have its target rewritten even though the target is outside this
 * plugin's directory. The root itself is checked as well: a data root that is a
 * link would send every call through it. An enumeration that fails stops the walk
 * and is reported, because a walk that quietly returns fewer paths than there are
 * would let the restriction proceed over a tree it never actually inspected.
 * @param root - Absolute plugin data root to walk.
 * @returns the paths of the reparse points found, in walk order.
 * @throws when a directory under the root cannot be read.
 */
export declare function findReparsePoints(root: string): Promise<string[]>;
/**
 * Name the operating system recognises for the account running this process.
 * @returns the account name without a domain qualifier.
 */
export declare function grantedAccountFor(env?: NodeJS.ProcessEnv): string;
/**
 * Restrict the data root to the account running this process.
 *
 * On Windows a mode passed to `mkdir` is ignored and `chmod` only toggles the
 * read-only bit, so the mode above is recorded but not enforced and the
 * directory keeps the entries it inherits from the plugin parent. There is no
 * POSIX permission interface in Node for this platform, so the only public route
 * is the platform's own tool.
 *
 * The owning account is granted full control before anything is taken away and
 * is granted again if a later step fails, so an interrupted call never leaves the
 * directory without an entry for the account that has to write there.
 *
 * @param root - Absolute plugin data root to restrict.
 * @param platform - Platform the data root lives on.
 * @param exec - Runs one argument vector and resolves with its standard output.
 * @param owner - Account the plugin runs as.
 * @returns nothing.
 * @throws when the platform refuses the restriction, or when the result still names
 * an identity that must not keep access, so the store does not open over a
 * directory another local account can read.
 */
export declare function restrictDataRootToOwner(root: string, platform?: NodeJS.Platform, exec?: (argv: string[]) => Promise<string>, owner?: string): Promise<void>;
/**
 * Path of the plugin's own SQLite database.
 *
 * The path is a plain join under the data root, so the bundle's
 * `cordis.patch.yml` can point the backend here without the plugin reading
 * Host configuration at runtime.
 * @returns the absolute database path.
 */
/** Sub-directory of the data root that holds run evidence. */
export declare const EVIDENCE_DIR = "evidence";
/** File path of the SQLite medium. */
export declare function databasePath(): string;
/**
 * The directory a run's evidence belongs in.
 *
 * Evidence is the plugin's own record of what a test actually did, so it lives
 * under the plugin's data root rather than wherever the browser happened to
 * write a file.
 * @param runKey - Run whose evidence directory to locate.
 * @returns the absolute directory path for that run.
 */
export declare function evidenceDir(runKey: string): string;
/**
 * The plugin's unit declaration.
 *
 * Declared once at module load so a malformed descriptor fails loud before any
 * medium is touched. `single` keeps reads at an exact version match, so a
 * database written by a newer plugin build refuses to open instead of reading
 * as empty.
 */
export declare const WEB_TEST_UNIT: KvUnitDescriptor;
//# sourceMappingURL=store.d.ts.map