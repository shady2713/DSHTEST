/**
 * One isolated browser per role, with the model locked to the active role.
 *
 * The stock Playwright MCP provider mounts one browser per Session and offers
 * no tool that creates a second context, so two roles acting at once cannot
 * hold separate cookies through it. This module mounts one MCP server per role
 * instead: each runs the same pinned `@playwright/mcp` CLI with `--isolated`,
 * so every role gets its own Chromium process with its own cookie jar and
 * storage. It owns routing and release only — the browser, the agent loop, and
 * the host stay the ones the host already ships.
 *
 * Reachability is enforced with the host's own `tools.restrict`: every role's
 * tools are denied except the active role's, so the model has no path to
 * another role's browser while another role is active.
 *
 * @module dsh-plugin-web-test/src/role-browser
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context, Disposable } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type ToolsService from '@deepseek-ai/dsh-tools';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import { z } from 'zod';
/** Loader identity of this service's row. */
export declare const name = "webTestRoleBrowsers";
/** Browser settings the operator configures for the test preset. */
export type RoleBrowserConfig = z.infer<typeof RoleBrowserPool.Config>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Per-role browser resources, owned by this plugin's own loader row. */
        webTestRoleBrowsers: RoleBrowserPool;
    }
}
/** Suffix of the tools this module lets the model reach for the active role. */
export declare const BROWSER_TOOL_SUFFIX = "__";
/** How long a role's MCP server may take to come up before the switch fails. */
declare const ROLE_STARTUP_TIMEOUT_MS = 60000;
/** What one role's browser resource is and how to address it. */
/**
 * The identity one mounted role browser belongs to.
 *
 * Every field is what an authorisation has to match: the declared project and
 * environment revision, the run and its generation, the role, and the exact
 * mount the tool namespace names.
 */
export interface MountOwner {
    /** Project whose environment declares the role. */
    projectKey: string;
    /** Confirmed environment revision the role belongs to. */
    environmentKey: string;
    /** Run acting as the role; empty before a run exists. */
    runKey: string;
    /** Declared role name. */
    role: string;
    /** Run generation the mount was created under. */
    generation: number;
    /** MCP server name, which is the tool namespace's identity. */
    serverName: string;
    /** Session the mount belongs to; another session may not drive it. */
    sessionId: string;
}
/**
 * The mount keys one run owns.
 *
 * Selection is by the mount's own owner, never by a role name: two runs in one
 * session can each declare `buyer`, and a release that reached for the role
 * reached whichever mount happened to be filed under it.
 * @param owners - Every mounted browser's owner.
 * @param runKey - Run whose mounts are wanted.
 * @returns the distinct keys of that run's mounts.
 */
export declare function mountKeysOfRun(owners: MountOwner[], runKey: string): string[];
/**
 * Every mounted browser's key.
 * @param owners - Every mounted browser's owner.
 * @returns the distinct keys of all mounts.
 */
export declare function allMountKeys(owners: MountOwner[]): string[];
/**
 * Run every disposer in turn and report the ones that refused.
 *
 * A teardown that fails must not stop the sweep, and the caller must not treat a
 * pool as empty afterwards: the disposer stays filed under its own key so the
 * next release retries it. `releaseAll` and `releaseRun` both funnel through
 * here so neither can forget the sweep.
 * @param dispose - Releases one mount by its key; throws when it refused.
 * @param keys - The keys to release, in order.
 * @returns One message per disposer that threw; empty when all of them closed.
 */
export declare function disposeAll(dispose: (key: string) => Promise<void>, keys: readonly string[]): Promise<string[]>;
/**
 * The tool namespace one owner's browser answers on.
 *
 * Read from the mount filed under that owner, never from the newest mount of the
 * role: two runs in one session can each declare `buyer`, and reading whichever
 * started last would read an account the caller does not own. With no mount yet
 * the namespace is derived from the role, which is the name the provider would
 * have used for its first mount.
 * @param started - Mounted browsers by their owner key.
 * @param owner - Identity the read belongs to.
 * @returns The `mcp__<server>__` namespace to call through.
 */
export declare function namespaceFor(started: ReadonlyMap<string, RoleBrowser>, owner: BrowserOwner): string;
/**
 * File a freshly mounted browser under its owner.
 *
 * The claim is written in the same step as the mount, not after the identity has
 * been confirmed. A window in which the mount existed but nothing owned it left
 * the plugin's own identity read refused by its own guard, and left the browser
 * unreleased when its run was cancelled.
 * @param started - Mounted browsers by owner key.
 * @param owners - Each mounted browser's owner, by server name.
 * @param claims - Which run and generation owns each server name.
 * @param key - The owner key the mount is filed under.
 * @param owner - Identity that mounted it.
 * @param browser - The browser itself.
 */
export declare function recordMount(started: Map<string, RoleBrowser>, owners: Map<string, MountOwner>, claims: Map<string, {
    runKey: string;
    generation: number;
}>, key: string, owner: BrowserOwner, browser: RoleBrowser): void;
/**
 * Take one mount out of the pool's tracking, and hand back what has to be put
 * back if its teardown refuses.
 *
 * Releasing is two steps: stop tracking the mount, then await its disposer. If
 * that disposer throws, the mount is still live, so its disposer, its browser and
 * its owner all go back under the names they had. Dropping them would let a later
 * release report an empty pool while the browser was still running.
 * @param mounts - Disposers by owner key.
 * @param started - Mounted browsers by owner key.
 * @param owners - Each mounted browser's owner, by server name.
 * @param claims - Which run and generation owns each server name.
 * @param keysByRole - Which owner keys each role has mounts under.
 * @param key - The owner key being released.
 * @returns The disposer to await, plus the records to restore when it throws.
 */
export interface DetachedMount {
    /** Disposer to await; undefined when the key held no mount. */
    dispose: (() => Promise<void>) | undefined;
    /** The browser that was filed under `key`, if any. */
    browser: RoleBrowser | undefined;
    /** The owner that was filed under the browser's server name, if any. */
    owner: MountOwner | undefined;
}
/**
 * Stop tracking one mounted browser.
 * @param mounts - Disposers by owner key.
 * @param started - Mounted browsers by owner key.
 * @param owners - Each mounted browser's owner, by server name.
 * @param claims - Which run and generation owns each server name.
 * @param keysByRole - Which owner keys each role has mounts under.
 * @param key - The owner key being released.
 * @returns What has to be restored if the disposer refuses.
 */
export declare function detachMount(mounts: Map<string, () => Promise<void>>, started: Map<string, RoleBrowser>, owners: Map<string, MountOwner>, claims: Map<string, {
    runKey: string;
    generation: number;
}>, keysByRole: Map<string, Set<string>>, key: string): DetachedMount;
/**
 * Put a refused mount back under the names it had before its teardown.
 * @param mounts - Disposers by owner key.
 * @param started - Mounted browsers by owner key.
 * @param owners - Each mounted browser's owner, by server name.
 * @param keysByRole - Which owner keys each role has mounts under.
 * @param key - The owner key whose teardown refused.
 * @param detached - What {@link detachMount} handed back.
 */
export declare function restoreMount(mounts: Map<string, () => Promise<void>>, started: Map<string, RoleBrowser>, owners: Map<string, MountOwner>, keysByRole: Map<string, Set<string>>, key: string, detached: DetachedMount): void;
export interface RoleBrowser {
    /** Role name the run declared for this browser. */
    readonly role: string;
    /** MCP server identity, which is also the tool namespace. */
    readonly serverName: string;
    /** Every tool this role's browser registers. */
    readonly toolNames: readonly string[];
}
/**
 * The identity that owns a role browser.
 *
 * A role name alone is not an owner: the same `buyer` is declared by different
 * projects and environments, and each run may hold its own. Keying on the name
 * alone would hand one run the browser another run signed in on, so the key is
 * built from the project, the environment, the run and the role together.
 */
export interface BrowserOwner {
    /** Session the mount belongs to; another session may not drive it. */
    sessionId: string;
    /**
     * Run generation the mount is created under.
     *
     * The caller supplies it from the run it is mounting for. Reading it back from
     * the pool instead cannot work: the mount does not exist yet at that point, so
     * the lookup returns nothing and every mount would be filed as generation 0.
     */
    generation: number;
    /** Project whose environment declares the role. */
    projectKey: string;
    /** Confirmed environment revision the role belongs to. */
    environmentKey: string;
    /** Run acting as the role; empty before a run exists. */
    runKey: string;
    /** Declared role name. */
    role: string;
}
/** A role's browser that came up, and the account the site reported for it. */
export interface VerifiedRole extends RoleBrowser {
    /** The account the site answered with, not the role name the run declared. */
    readonly account: string;
}
/** What a role's site answered when its identity was checked. */
export interface IdentityAnswer {
    /** Account the site reported, or an empty string when it reported none. */
    account: string;
    /** Raw response, kept so a failure can be reported as the site stated it. */
    detail: string;
}
/**
 * Per-role browser resources for one plugin instance.
 *
 * Browsers are started when a run switches to a role and released when the run
 * finishes, the plugin drains, or the process ends. Nothing here touches a
 * browser another session or an ordinary DSH conversation owns.
 */
export declare class RoleBrowserPool extends Service {
    /** Started role browsers, in the order they were created. */
    /**
     * The pool's tracking maps, read-only.
     *
     * Their element types are exported contracts (`RoleBrowser`, `MountOwner`), and
     * what the pool still holds cannot be observed without the provider. Exposing
     * them lets a caller read the pool's state and lets a test drive a real
     * disposer through it; nothing outside this class may add to or change them.
     */
    readonly started: Map<string, RoleBrowser>;
    /**
     * Roles whose mount is in flight, so a second caller waits on the same one.
     *
     * The owner is held beside the promise rather than only being written when the
     * mount completes. A release that arrives in between selects its targets from
     * the owners, and a start that has not finished has none yet, so without this
     * the release finds nothing and the browser the start then completes stays up
     * for a run that no longer exists.
     */
    private readonly pending;
    /**
     * Keys released while their mount was still in flight, consumed by that start
     * once it completes. Without it the release finds nothing to close and the
     * browser the start then brings up stays for a run that no longer exists.
     */
    private readonly abandoned;
    /** Disposers returned by `mountSessionMcp`, one per started role. */
    /**
     * Mounts that have not been released, keyed by owner key.
     *
     * Exposed read-only because whether a browser is actually running cannot be
     * observed without the provider: a caller that needs to know what the pool
     * still holds reads this, and nothing outside the class may add to it.
     */
    readonly mounts: Map<string, Disposable<Promise<void>>>;
    /** The role this pool currently drives; the host allows only one at a time. */
    private activeRole;
    /**
     * Agents the host has announced, in the order they appeared.
     *
     * A role confirmed before its session exists has no Agent yet, and a role
     * switched to afterwards belongs to one that already exists. Recording the
     * announcements is what lets both cases open a client without the pool
     * inventing an Agent or a lifecycle event of its own.
     */
    readonly knownAgents: Set<Agent>;
    /**
     * Which run and generation each started role browser belongs to.
     *
     * A role name is not an owner: two runs in one session can each declare
     * `buyer`, and a call queued against the first must not be allowed to prepare
     * an identity on the second. The claim is recorded when a run starts acting as
     * a role and dropped with the browser, so preparation can be judged against the
     * run that actually owns the resource the call would drive.
     */
    readonly claims: Map<string, {
        runKey: string;
        generation: number;
    }>;
    /**
     * Who each mounted browser belongs to, by MCP server name.
     *
     * The guard judges a browser call against the mount it names, so the mount has
     * to carry its own owner rather than be inferred from a role name, a session or
     * the newest mount of a role.
     */
    readonly owners: Map<string, MountOwner>;
    /**
     * The composite key each started role is filed under, by role name.
     *
     * Releasing by role name is a last resort for a caller that does not know the
     * owner; once two runs hold the same role this is the only way to find a key at
     * all, so a release that names a run releases that run's browser and no other.
     */
    /**
     * Every key a role has been mounted under. A role mounted twice keeps two
     * keys, and releasing one of them must release the other as well: recording
     * only the newest left the earlier entry in `mounts` with nothing reaching it.
     */
    private readonly keysByRole;
    /** How many times each role has been mounted, so a re-mount can take a new name. */
    private readonly mountCount;
    /**
     * Record which run and generation owns a role's browser.
     * @param role - The role being acted as.
     * @param runKey - Run that switched to the role.
     * @param generation - Run generation at the moment of the switch.
     */
    claim(serverName: string, runKey: string, generation: number): void;
    /**
     * The run and generation that own a role's browser.
     * @param role - The role to look up.
     * @returns the owner, or undefined when no run has claimed the role.
     */
    claimOf(serverName: string): {
        runKey: string;
        generation: number;
    } | undefined;
    /**
     * The identity one mounted browser belongs to.
     *
     * Keyed by the MCP server name rather than by role, because a role name is
     * not an owner: two runs in one session can each declare `buyer`, and a call
     * queued against the first must not be answered from the second.
     * @param serverName - Server name the tool namespace carries.
     * @returns the owner, or undefined when nothing is mounted under that name.
     */
    ownerOfServer(serverName: string): MountOwner | undefined;
    /**
     * The server name one owner's browser is reachable under.
     * @param owner - Identity being looked up.
     * @returns the server name, or an empty string when that owner has no mount.
     */
    serverNameFor(owner: BrowserOwner): string;
    /**
     * @param ctx - Owning context, which supplies the tools and browser services
     * the provider rows need.
     * @param executablePath - Chromium the role browsers launch; the host
     * installs no Playwright browser build, so this is a standalone Chrome.
     * @param headless - Whether role browsers run without a window.
     */
    static inject: string[];
    /** Browser settings the operator chooses on the loader row. */
    static Config: z.ZodObject<{
        executablePath: z.ZodOptional<z.ZodString>;
        headless: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strip>;
    /**
     * @param ctx - Owning context, which supplies the browser and tool services
     * each role's MCP server needs.
     * @param config - Chromium choice and window mode.
     */
    constructor(ctx: Context, config: RoleBrowserConfig);
    private readonly executablePath;
    private readonly headless;
    /**
     * The map key one owner's browser is filed under.
     * @param owner - The identity that owns the browser.
     * @returns a key no other owner shares.
     */
    /**
     * The exact MCP server name a tool namespace carries.
     *
     * Unlike `roleOf` this keeps the generation suffix, because the suffix is
     * what distinguishes one mount of a role from the mount that replaced it.
     * @param toolName - Full tool name as dispatched.
     * @returns the server name, or an empty string when this is not one of ours.
     */
    static serverNameOf(toolName: string): string;
    /**
     * The run generation one owner's mount was created under.
     * @param owner - Identity being mounted.
     * @returns the generation recorded by the claim, or 0 when none was claimed.
     */
    private generationOf;
    /**
     * Release one mount by the key it is filed under.
     *
     * `releaseRole` is for a role name; this is for the composite key `mounts`
     * holds, which is what a bulk release actually has.
     * @param key - Key the mount is filed under.
     */
    private releaseByKey;
    static keyOf(owner: BrowserOwner): string;
    /**
     * Start a role's browser if it is not already up.
     *
     * Starting is idempotent because a run may switch back and forth between
     * roles, and a second browser for the same role would drop the login the
     * first one established.
     * @param role - Declared role name.
     * @returns the role's browser resource.
     */
    ensure(owner: BrowserOwner): Promise<RoleBrowser>;
    /**
     * Make a role the one this pool drives, leaving any other mounted.
     *
     * A role's browser is kept once started. The provider gives every Agent its own
     * MCP client under its own scope, and each role registers a distinct
     * `browserUse` name, so two roles coexist rather than contending for one
     * browser. Releasing the previous role here was what made cross-role work
     * impossible: the first role's login and cookies were destroyed before the
     * second role existed.
     * @param role - The role to act as.
     * @returns the role's browser resource.
     */
    switchTo(owner: BrowserOwner): Promise<RoleBrowser>;
    /**
     * The role this pool currently drives.
     * @returns the active role, or undefined when none is mounted.
     */
    active(): string | undefined;
    /**
     * Close one role's browser and wait for it.
     *
     * The effect that mounted the provider is disposed and awaited, so this
     * returns only after the provider has torn the browser down. A browser that
     * fails to close is reported rather than dropped.
     * @param role - The role to release.
     * @returns once the browser is closed.
     */
    /**
     * Release every browser one run owns, and nothing belonging to another run.
     *
     * A run that acted as two roles owns two browsers, so releasing only the role it
     * happens to be acting as leaves the other one running after the run is closed.
     * The claims are the record of ownership, so the set released here is exactly
     * the runs that claimed the roles, not every browser in the pool.
     * @param runKey - Run whose browsers are being released.
     * @returns once each released browser is closed.
     */
    releaseRun(runKey: string): Promise<void>;
    releaseRole(role: string): Promise<void>;
    /**
     * Record one more key a role is mounted under.
     * @param role - Declared role name.
     * @param key - Key the mount is filed under.
     */
    /**
     * File one owner key under the role that mounted it.
     *
     * Part of the pool's public surface because which keys a role still holds is
     * what `releaseRole` acts on, and that cannot be observed from outside without
     * the provider. Adding a key here without a mount under it only makes a later
     * role release a no-op for that key.
     * @param role - Role that owns the mount.
     * @param key - Owner key the mount is filed under.
     */
    addKeyForRole(role: string, key: string): void;
    /**
     * Mount one role's MCP server and record it as started.
     * @param role - Declared role name.
     * @param browser - The resource to record once the server is mounted.
     * @returns once the server is mounted.
     */
    private mountBrowser;
    /**
     * Every role browser this pool has started.
     *
     *
     * Read at activation time: the provider registers an MCP server's tools when
     * a Session's agent activates, so a role started moments ago has none until
     * then, and the deny list is rebuilt each time the active role changes.
     * @returns the started role browsers.
     */
    /**
     * Who each mounted role browser belongs to.
     *
     * Read by the execution guard to judge a call against the mount it names, and
     * by a caller that has to report what is still up.
     * @returns one owner per mounted browser.
     */
    ownedBrowsers(): MountOwner[];
    list(): RoleBrowser[];
    /**
     * Tool names belonging to roles other than the active one.
     *
     * The model must not reach them: a second role's browser is a different
     * account, and using it would attribute one role's actions to another.
     * @param activeRole - Role the run is acting as, or an empty string.
     * @returns names to deny for the current activation.
     */
    forbiddenTools(activeRole: string): string[];
    /**
     * The tool namespace a role's browser actions live under.
     *
     * @param role - Declared role name.
     * @returns the prefix, for matching a tool back to its role.
     */
    static namespaceOf(role: string): string;
    /**
     * Which role a tool name belongs to, when it is one of ours.
     *
     * @param toolName - Global tool name as registered.
     * @returns the role name, or an empty string when the tool is not ours.
     */
    static roleOf(toolName: string): string;
    /**
     * Read the signed-in account back from the site, through this role's browser.
     *
     * Two nested tool calls: navigate to the identity endpoint, then read the
     * page text. Both are dispatched through the tools pipeline as nested calls
     * of the call that asked for the role, so the whole thing is logged as one
     * operation rather than as a browser action nobody declared.
     * @param tools - Tools service the role's browser tools are registered on.
     * @param exec - Execution identity of the call asking for verification.
     * @param role - Role whose browser to ask.
     * @param identityUrl - Site endpoint that reports the current account.
     * @returns the account the site reported and the text it reported it in.
     */
    readAccount(tools: ToolsService, exec: ToolRunContext, owner: BrowserOwner, identityUrl: string, capability?: {
        token: string;
    }): Promise<IdentityAnswer>;
    /**
     * Release every browser this pool started.
     *
     * Called when the plugin drains, which is also what a run's completion does,
     * so a run cannot leave a Chromium running after it stops.
     * @returns once every role's server is disposed.
     */
    releaseAll(): Promise<void>;
}
/**
 * The page function that reports identity.
 *
 * It reads a marker the identity endpoint sets, so a login page or an error
 * page cannot be mistaken for a signed-in account: an unsigned page answers
 * with an empty string rather than with whatever text happens to be on it.
 */
export declare const IDENTITY_PROBE = "() => JSON.stringify({ account: document.body.dataset.webtestAccount ?? \"\", url: location.href, title: document.title })";
/**
 * How long a role browser may take to come up.
 *
 * Exposed so a caller can apply its own deadline instead of inventing one.
 */
export { ROLE_STARTUP_TIMEOUT_MS };
export default RoleBrowserPool;
//# sourceMappingURL=role-browser.d.ts.map