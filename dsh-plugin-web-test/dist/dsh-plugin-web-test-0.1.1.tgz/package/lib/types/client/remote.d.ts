/**
 * Generated Remote contribution for the Web testing namespace.
 *
 * Written by dsh-plugin-web-test/scripts/generate-typert.mjs — do not edit.
 *
 * @module dsh-plugin-web-test/client/remote
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import { z } from 'zod';
declare const projectRecord: z.ZodObject<{
    schemaVersion: z.ZodLiteral<3>;
    kind: z.ZodLiteral<"project">;
    key: z.ZodString;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
    sourceRoot: z.ZodString;
    baseUrl: z.ZodString;
}, z.core.$strip>;
declare const pluginStatus: z.ZodObject<{
    version: z.ZodString;
    state: z.ZodUnion<readonly [z.ZodLiteral<"active">, z.ZodLiteral<"draining">]>;
    dataRoot: z.ZodString;
    schemaVersion: z.ZodNumber;
    recordCounts: z.ZodObject<{
        project: z.ZodNumber;
        'environment-revision': z.ZodNumber;
        run: z.ZodNumber;
        policy: z.ZodNumber;
        'case-result': z.ZodNumber;
    }, z.core.$strip>;
    dshVersion: z.ZodString;
}, z.core.$strip>;
declare const environmentRevisionRecord: z.ZodObject<{
    schemaVersion: z.ZodLiteral<3>;
    kind: z.ZodLiteral<"environment-revision">;
    key: z.ZodString;
    projectKey: z.ZodString;
    revision: z.ZodNumber;
    name: z.ZodString;
    url: z.ZodString;
    nature: z.ZodEnum<{
        unknown: "unknown";
        test: "test";
        production: "production";
    }>;
    dataOperations: z.ZodEnum<{
        "read-only": "read-only";
        "business-entry-writes": "business-entry-writes";
    }>;
    roles: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        accountRef: z.ZodString;
    }, z.core.$strip>>;
    scopeNotes: z.ZodString;
    modelRef: z.ZodString;
    viewport: z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
    confirmedAtMs: z.ZodNumber;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
declare const caseResultRecord: z.ZodObject<{
    schemaVersion: z.ZodLiteral<3>;
    kind: z.ZodLiteral<"case-result">;
    key: z.ZodString;
    runKey: z.ZodString;
    projectKey: z.ZodString;
    environmentRevisionKey: z.ZodString;
    caseKey: z.ZodString;
    outcome: z.ZodEnum<{
        passed: "passed";
        failed: "failed";
        skipped: "skipped";
        blocked: "blocked";
        incomplete: "incomplete";
    }>;
    steps: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        intent: z.ZodString;
        observed: z.ZodString;
        outcome: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
            skipped: "skipped";
            blocked: "blocked";
        }>;
        evidencePath: z.ZodString;
    }, z.core.$strip>>;
    assertions: z.ZodArray<z.ZodObject<{
        expected: z.ZodString;
        actual: z.ZodString;
        outcome: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
            skipped: "skipped";
            blocked: "blocked";
        }>;
        reason: z.ZodString;
    }, z.core.$strip>>;
    evidencePaths: z.ZodArray<z.ZodString>;
    openQuestions: z.ZodArray<z.ZodString>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
declare const runRecord: z.ZodObject<{
    schemaVersion: z.ZodLiteral<3>;
    kind: z.ZodLiteral<"run">;
    key: z.ZodString;
    projectKey: z.ZodString;
    environmentRevisionKey: z.ZodString;
    phase: z.ZodEnum<{
        analysis: "analysis";
        planning: "planning";
        execution: "execution";
        reporting: "reporting";
        cleanup: "cleanup";
    }>;
    status: z.ZodEnum<{
        blocked: "blocked";
        queued: "queued";
        running: "running";
        "awaiting-user": "awaiting-user";
        "awaiting-business-time": "awaiting-business-time";
        paused: "paused";
        resuming: "resuming";
        completed: "completed";
        cancelled: "cancelled";
    }>;
    unresolvedOperations: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"not-dispatched">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"dispatching">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"dispatched">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<{
            "observed-success": "observed-success";
            "observed-absent": "observed-absent";
        }>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"unknown">;
        reason: z.ZodString;
    }, z.core.$strip>], "kind">>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
declare const policyRecord: z.ZodObject<{
    schemaVersion: z.ZodLiteral<3>;
    kind: z.ZodLiteral<"policy">;
    key: z.ZodString;
    projectKey: z.ZodString;
    externalActions: z.ZodEnum<{
        skip: "skip";
        confirm: "confirm";
    }>;
    defaultViewport: z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
    failureSimulation: z.ZodEnum<{
        excluded: "excluded";
        included: "included";
    }>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
/** Result and parameter types, inferred from the same schemas the wire uses. */
type RemotePluginStatus = z.infer<typeof pluginStatus>;
type RemoteProject = z.infer<typeof projectRecord>;
type RemoteEnvironmentRevision = z.infer<typeof environmentRevisionRecord>;
type RemotePolicy = z.infer<typeof policyRecord>;
type RemoteCaseResult = z.infer<typeof caseResultRecord>;
type RemoteRun = z.infer<typeof runRecord>;
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteNamespace77656254657374 {
        status: () => Promise<{
            ok: true;
            value: RemotePluginStatus;
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        putProject: (project: RemoteProject) => Promise<{
            ok: true;
            value: RemoteProject;
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        listProjects: () => Promise<{
            ok: true;
            value: RemoteProject[];
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        putEnvironment: (environment: RemoteEnvironmentRevision) => Promise<{
            ok: true;
            value: RemoteEnvironmentRevision;
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        listEnvironments: (projectKey: string) => Promise<{
            ok: true;
            value: RemoteEnvironmentRevision[];
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        putPolicy: (policy: RemotePolicy) => Promise<{
            ok: true;
            value: RemotePolicy;
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        listCaseResults: (runKey: string) => Promise<{
            ok: true;
            value: RemoteCaseResult[];
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        buildReport: (runKey: string) => Promise<{
            ok: true;
            value: {
                markdown: string;
            };
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        listRuns: () => Promise<{
            ok: true;
            value: RemoteRun[];
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        controlRun: (runKey: string, action: 'pause' | 'resume' | 'cancel') => Promise<{
            ok: true;
            value: RemoteRun;
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
        getRun: (runKey: string) => Promise<{
            ok: true;
            value: RemoteRun;
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
    }
    interface TypertRemoteNamespaceMap {
        "webTest": TypertRemoteNamespace77656254657374;
    }
}
export declare const TYPERT_REMOTE: TypertRemoteContribution;
export default TYPERT_REMOTE;
//# sourceMappingURL=remote.d.ts.map