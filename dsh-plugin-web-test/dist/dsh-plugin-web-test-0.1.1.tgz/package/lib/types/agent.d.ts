/**
 * Web testing Agent composition.
 *
 * This module is mounted inside the `web-test` agent preset only. It
 * contributes the test instructions, the test tools, and the execution guard,
 * so none of it reaches a normal DSH session.
 *
 * The restriction is an allowlist enforced by `ctx.tools.guard`, which runs in
 * the tool pipeline before any tool body. A guard has no allow result, so no
 * other listener or approval can turn a denial back into permission, and an
 * Agent that retained this retired preset after the plugin was disabled still
 * meets the guard, which additionally consults the store's lifecycle state.
 *
 * @module dsh-plugin-web-test/agent
 */
import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
/** Loader row id for this composition inside the preset. */
export declare const name = "web-test-agent";
/** Cordis service injection for this composition. */
export declare const inject: string[];
/** Identity of the agent preset the operator selects explicitly. */
export declare const PRESET_ID = "web-test";
/**
 * Prefix every tool this plugin contributes in a test session.
 *
 * The guard admits these plus the browser provider's `mcp__<server>_` tools,
 * and denies everything else, so a test Agent cannot reach the host's shell,
 * filesystem, or session-editing tools even if a future preset or a model
 * prompt asks it to.
 */
export declare const TOOL_PREFIX = "web_test_";
/**
 * Prefix the browser provider's tools carry.
 *
 * The official per-Session Playwright MCP provider registers its server under
 * the fixed name `playwright-mcp`, so its tools are `mcp__playwright-mcp__*`.
 * The allowlist names that prefix explicitly rather than accepting every
 * `mcp__*` tool, so a globally installed browser provider's tools stay outside
 * a test session even if it is loaded at the same time.
 */
export declare const BROWSER_TOOL_PREFIX = "mcp__playwright-mcp__";
/** Instructions given to a Web testing Agent. */
export declare const TEST_INSTRUCTIONS: string;
/**
 * Tools that stay reachable while a run is held.
 *
 * A hold must not make a run unbookkeepable: the model has to be able to report
 * what happened, record that a dispatch was lost, and end a wait. Each of these
 * records or retires state instead of dispatching a new test action, so allowing
 * them cannot drive the browser.
 */
export declare const HELD_RUN_ALLOWED_TOOLS: readonly string[];
/**
 * Decide whether one tool call may run in a test session.
 *
 * @param execution - the call about to enter a tool body.
 * @param store - the run owner, consulted for the session's held run.
 * @param sessionId - identity of the session asking, empty when it has none.
 * @returns a denial reason, or `undefined` to leave the call allowed.
 */
export declare function guardReason(execution: Readonly<{
    name: string;
}>, store?: {
    holdForSession: (sessionId: string) => {
        runKey: string;
        status: string;
    } | undefined;
}, sessionId?: string): string | undefined;
/** Result shape of the status tool, kept separate for reuse in tests. */
export declare const statusResultSchema: z.ZodObject<{
    state: z.ZodEnum<{
        active: "active";
        draining: "draining";
    }>;
    evidenceRoot: z.ZodString;
    version: z.ZodString;
    projectCount: z.ZodNumber;
    runCount: z.ZodNumber;
    interruptedRuns: z.ZodArray<z.ZodString>;
    unknownOperations: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
/** Validated result of the status tool. */
export type WebTestStatusResult = z.infer<typeof statusResultSchema>;
export declare function apply(ctx: Context): void;
//# sourceMappingURL=agent.d.ts.map