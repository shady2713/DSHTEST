/**
 * Run report generation.
 *
 * A report is derived from recorded results only, so what it states can be
 * traced back to a case the plugin accepted. Anything the run could not settle
 * is carried through as an open question rather than smoothed into a pass.
 *
 * The Markdown, HTML and JSON exports share this one derivation, so the three
 * cannot disagree about what a run did.
 *
 * @module dsh-plugin-web-test/report
 */
import type { CaseResultRecord, OperationRecord, RunRecord } from './types.ts';
/** One count in a run's outcome tally. */
interface Tally {
    passed: number;
    failed: number;
    skipped: number;
    blocked: number;
    incomplete: number;
}
/** Everything one run's report is derived from. */
export interface ReportInput {
    /** The run the report covers. */
    runKey: string;
    /** Its recorded case results, in key order. */
    results: CaseResultRecord[];
    /** The run record, so the report states the run's own control state. */
    run?: RunRecord;
    /** Its business-changing operations, so an unresolved one reaches the report. */
    operations?: OperationRecord[];
}
/**
 * The run-level verdict, as a machine-readable value.
 *
 * `undetermined` is the only honest verdict when a question is open, a case
 * failed, or nothing was recorded; `passed` requires every recorded case to have
 * passed with nothing left to settle.
 */
export type Verdict = 'passed' | 'failed' | 'undetermined' | 'empty';
/** One run's report in every exported form. */
export interface ReportBundle {
    runKey: string;
    verdict: Verdict;
    /** Rendered Markdown, the form a person reads in a review. */
    markdown: string;
    /** Rendered HTML, the form a browser opens. */
    html: string;
    /** The same facts as JSON, the form a tool reads. */
    json: ReportJson;
}
/** The machine-readable report. */
export interface ReportJson {
    schemaVersion: number;
    runKey: string;
    verdict: Verdict;
    runStatus: RunRecord['status'] | undefined;
    tally: Tally;
    /** Questions the run could not settle, which is why a verdict may be undetermined. */
    openQuestions: string[];
    cases: CaseResultRecord[];
    /** Operations whose outcome was never established, which the report must not hide. */
    unresolvedOperations: {
        operationKey: string;
        intent: string;
        dispatch: string;
        reason: string;
    }[];
}
/** Report format version, so a consumer can tell the layout apart. */
export declare const REPORT_SCHEMA_VERSION = 1;
/**
 * Build every exported form of one run's report from the same facts.
 * @param input - The run, its results, and its operations.
 * @returns the report in Markdown, HTML and JSON.
 */
export declare function buildReportBundle(input: ReportInput): ReportBundle;
/**
 * Render one run's report as Markdown.
 *
 * @param runKey - Run the report covers.
 * @param results - The case results recorded for that run, in key order.
 * @returns the report in Markdown.
 */
export declare function buildReport(runKey: string, results: CaseResultRecord[]): string;
export {};
//# sourceMappingURL=report.d.ts.map