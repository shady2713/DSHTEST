/**
 * Durable record schemas for the Web testing plugin.
 *
 * These Zod schemas are the single source of truth: the storage domain
 * validates every record against them at the durable boundary, and
 * `types.ts` derives its exported record types from them, so a stored record
 * and its TypeScript type cannot drift apart.
 *
 * @module dsh-plugin-web-test/records
 */
import { z } from 'zod';
/**
 * Durable format version written on every record.
 *
 * The version stays at `3` while record fields are added, because a
 * `single`-layout unit refuses every stamp but its own and the backend offers no
 * way to write a higher stamp over a lower one: bumping the number would strand
 * every database an earlier build wrote instead of migrating it. Fields added
 * after v3 therefore carry a documented default, so an older build reading a
 * newer record ignores the extra fields and a newer build reading an older
 * record fills the defaults. A stamp this schema does not know still refuses to
 * open, which is the guarantee the version exists for.
 */
export declare const SCHEMA_VERSION = 3;
/** A Web testing project: where the code under test lives and how to reach it. */
export declare const projectRecordSchema: z.ZodObject<{
    kind: z.ZodLiteral<"project">;
    key: z.ZodString;
    sourceRoot: z.ZodString;
    baseUrl: z.ZodString;
    schemaVersion: z.ZodLiteral<3>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
/** A browser viewport the confirmed cases execute at. */
export declare const viewportSchema: z.ZodObject<{
    width: z.ZodNumber;
    height: z.ZodNumber;
}, z.core.$strip>;
/**
 * What the user declared about one entry point's environment.
 *
 * `nature` is never inferred from a hostname or a successful login: an
 * unconfirmed entry stays `unknown`, which withholds business mutations and
 * disruptive failure simulation until the user authorizes them.
 */
export declare const environmentNatureSchema: z.ZodEnum<{
    test: "test";
    production: "production";
    unknown: "unknown";
}>;
/** How far the declared data scope permits business-changing operations. */
export declare const dataOperationScopeSchema: z.ZodEnum<{
    "read-only": "read-only";
    "business-entry-writes": "business-entry-writes";
}>;
/** One role the cases may act as, with a credential reference the plugin never stores. */
export declare const roleSchema: z.ZodObject<{
    name: z.ZodString;
    accountRef: z.ZodString;
}, z.core.$strip>;
/** One revision of a project's environment declaration. */
export declare const environmentRevisionRecordSchema: z.ZodObject<{
    kind: z.ZodLiteral<"environment-revision">;
    key: z.ZodString;
    projectKey: z.ZodString;
    revision: z.ZodNumber;
    name: z.ZodString;
    url: z.ZodString;
    nature: z.ZodEnum<{
        test: "test";
        production: "production";
        unknown: "unknown";
    }>;
    dataOperations: z.ZodEnum<{
        "read-only": "read-only";
        "business-entry-writes": "business-entry-writes";
    }>;
    roles: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        accountRef: z.ZodString;
    }, z.core.$strip>>;
    scopeNotes: z.ZodString;
    modelRef: z.ZodString;
    viewport: z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
    confirmedAtMs: z.ZodNumber;
    schemaVersion: z.ZodLiteral<3>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
/** Project-level execution policy applied to confirmed cases. */
export declare const policyRecordSchema: z.ZodObject<{
    kind: z.ZodLiteral<"policy">;
    key: z.ZodString;
    projectKey: z.ZodString;
    externalActions: z.ZodEnum<{
        skip: "skip";
        confirm: "confirm";
    }>;
    defaultViewport: z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
    failureSimulation: z.ZodEnum<{
        excluded: "excluded";
        included: "included";
    }>;
    schemaVersion: z.ZodLiteral<3>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
/** One step of a confirmed case, as the model actually performed it. */
export declare const stepResultSchema: z.ZodObject<{
    index: z.ZodNumber;
    intent: z.ZodString;
    observed: z.ZodString;
    outcome: z.ZodEnum<{
        passed: "passed";
        failed: "failed";
        skipped: "skipped";
        blocked: "blocked";
    }>;
    evidencePath: z.ZodString;
}, z.core.$strip>;
/** One assertion the model checked, and what it found. */
export declare const assertionResultSchema: z.ZodObject<{
    expected: z.ZodString;
    actual: z.ZodString;
    outcome: z.ZodEnum<{
        passed: "passed";
        failed: "failed";
        skipped: "skipped";
        blocked: "blocked";
    }>;
    reason: z.ZodString;
}, z.core.$strip>;
/** The structured outcome of one confirmed case. */
export declare const caseResultRecordSchema: z.ZodObject<{
    kind: z.ZodLiteral<"case-result">;
    key: z.ZodString;
    runKey: z.ZodString;
    projectKey: z.ZodString;
    environmentRevisionKey: z.ZodString;
    caseKey: z.ZodString;
    outcome: z.ZodEnum<{
        passed: "passed";
        failed: "failed";
        skipped: "skipped";
        blocked: "blocked";
        incomplete: "incomplete";
    }>;
    steps: z.ZodArray<z.ZodObject<{
        index: z.ZodNumber;
        intent: z.ZodString;
        observed: z.ZodString;
        outcome: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
            skipped: "skipped";
            blocked: "blocked";
        }>;
        evidencePath: z.ZodString;
    }, z.core.$strip>>;
    assertions: z.ZodArray<z.ZodObject<{
        expected: z.ZodString;
        actual: z.ZodString;
        outcome: z.ZodEnum<{
            passed: "passed";
            failed: "failed";
            skipped: "skipped";
            blocked: "blocked";
        }>;
        reason: z.ZodString;
    }, z.core.$strip>>;
    evidencePaths: z.ZodArray<z.ZodString>;
    openQuestions: z.ZodArray<z.ZodString>;
    schemaVersion: z.ZodLiteral<3>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
/** Dispatch state of one business-changing operation. */
export declare const operationDispatchSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"not-dispatched">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"dispatching">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"dispatched">;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"settled">;
    outcome: z.ZodEnum<{
        "observed-success": "observed-success";
        "observed-absent": "observed-absent";
    }>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"unknown">;
    reason: z.ZodString;
}, z.core.$strip>], "kind">;
/** One test run and its control state. */
export declare const runRecordSchema: z.ZodObject<{
    kind: z.ZodLiteral<"run">;
    key: z.ZodString;
    projectKey: z.ZodString;
    environmentRevisionKey: z.ZodString;
    phase: z.ZodEnum<{
        analysis: "analysis";
        planning: "planning";
        execution: "execution";
        reporting: "reporting";
        cleanup: "cleanup";
    }>;
    status: z.ZodEnum<{
        blocked: "blocked";
        queued: "queued";
        running: "running";
        "awaiting-user": "awaiting-user";
        "awaiting-business-time": "awaiting-business-time";
        paused: "paused";
        resuming: "resuming";
        completed: "completed";
        cancelled: "cancelled";
    }>;
    unresolvedOperations: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"not-dispatched">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"dispatching">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"dispatched">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<{
            "observed-success": "observed-success";
            "observed-absent": "observed-absent";
        }>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"unknown">;
        reason: z.ZodString;
    }, z.core.$strip>], "kind">>;
    ownerSessionId: z.ZodDefault<z.ZodString>;
    activeRole: z.ZodDefault<z.ZodString>;
    waitingUntilMs: z.ZodDefault<z.ZodNumber>;
    waitingReason: z.ZodDefault<z.ZodString>;
    schemaVersion: z.ZodLiteral<3>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
/**
 * One business-changing operation inside a run.
 *
 * The record exists so a run's business effect is durable before the action that
 * causes it: a transport loss or a crash after a possible dispatch leaves the
 * operation in {@link operationDispatchSchema} `dispatching` or `unknown`, and
 * {@link WebTestStore.beginOperation} refuses to dispatch that intent again.
 * Replanning or issuing a new tool-call id does not authorize a repeat.
 */
export declare const operationRecordSchema: z.ZodObject<{
    kind: z.ZodLiteral<"operation">;
    key: z.ZodString;
    runKey: z.ZodString;
    operationKey: z.ZodString;
    intent: z.ZodString;
    role: z.ZodDefault<z.ZodString>;
    requestDigest: z.ZodString;
    dispatch: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"not-dispatched">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"dispatching">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"dispatched">;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"settled">;
        outcome: z.ZodEnum<{
            "observed-success": "observed-success";
            "observed-absent": "observed-absent";
        }>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"unknown">;
        reason: z.ZodString;
    }, z.core.$strip>], "kind">;
    schemaVersion: z.ZodLiteral<3>;
    label: z.ZodString;
    updatedAtMs: z.ZodNumber;
}, z.core.$strip>;
/**
 * Why a run currently refuses new test actions, keyed by what produced it.
 *
 * A hold is scoped to the run's owning session, so one session's hold never
 * stops another session's run. `resuming` is the state a run a host restart
 * interrupted lands in: it is neither executing nor the operator's choice, so it
 * waits for an explicit continuation.
 */
export declare const runHoldStatusSchema: z.ZodEnum<{
    "awaiting-user": "awaiting-user";
    "awaiting-business-time": "awaiting-business-time";
    paused: "paused";
    resuming: "resuming";
}>;
//# sourceMappingURL=records.d.ts.map